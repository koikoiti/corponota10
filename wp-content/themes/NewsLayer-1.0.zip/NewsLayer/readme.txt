NewsLayer theme by FThemes, http://fthemes.com
Online Demo: http://fthemes.com/demo/NewsLayer/
Theme URI: http://fthemes.com/newslayer-free-wordpress-theme/